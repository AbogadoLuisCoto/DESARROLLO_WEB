<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CRUD de Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <nav class="mb-4 bg-light p-3 rounded">
        <a href="index.php?controller=producto&action=index" class="btn btn-primary">Productos (Ej 1)</a>
        <a href="index.php?controller=curso&action=index" class="btn btn-outline-primary">Cursos (Ej 2)</a>
    </nav>
    <h2 class="mb-4">Administración de Productos</h2>
    <a href="index.php?controller=producto&action=crear" class="btn btn-success mb-3">Crear Nuevo Producto</a>
    
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped mb-0">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($productos)): ?>
                <tr><td colspan="6" class="text-center">No hay productos registrados.</td></tr>
                <?php else: ?>
                    <?php foreach ($productos as $p): ?>
                    <tr>
                        <td><?= htmlspecialchars($p['id']) ?></td>
                        <td><?= htmlspecialchars($p['nombre']) ?></td>
                        <td><?= htmlspecialchars($p['categoria']) ?></td>
                        <td>$<?= htmlspecialchars($p['precio']) ?></td>
                        <td><?= htmlspecialchars($p['stock']) ?></td>
                        <td>
                            <a href="index.php?controller=producto&action=editar&id=<?= $p['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="index.php?controller=producto&action=eliminar&id=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro de que desea eliminar este producto? Esta acción no se puede deshacer.');">Eliminar</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
