<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>I.E. Fermín Veras Rojas - Inicio</title>
    <link rel="stylesheet" href="bases_php/css/estilos.css">
</head>
<body>

    <header>
        <h1>Institución Educativa Fermín Veras Rojas</h1>
        <p>Portal de Gestión - Demostración GET y POST</p>
    </header>

    <nav>
        <a href="index.php?seccion=Inicio">Inicio</a>
        <a href="index.php?seccion=Unidades">Unidades</a>
        <a href="index.php?seccion=Contacto">Contacto</a>
    </nav>

    <div class="container">
        <h2>Sección Activa (Respuesta GET)</h2>
        <?php
        if (isset($_GET['seccion'])) {
            $seccion_seleccionada = htmlspecialchars($_GET['seccion']);
            echo "<div class='alert'>📌 Se ha seleccionado la sección: <strong>" . $seccion_seleccionada . "</strong></div>";
        } else {
            echo "<p>Por favor, haz clic en un enlace del menú superior para probar el método GET.</p>";
        }
        ?>
    </div>

    <div class="form-container">
    <h2 style="text-align: center; margin-top: 0;">Contacto</h2>
    <form action="/GET_Y_POST_COTO_LUIS/bases_php/php/bases.php" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required placeholder="Ingresa tu nombre">
        </div>
        <div class="form-group">
            <label for="correo">Correo electrónico:</label>
            <input type="email" id="correo" name="correo" required placeholder="ejemplo@correo.com">
        </div>
        <button type="submit">Enviar Información</button>
    </form>
</div>

</body>
</html>