<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servidor - Datos Procesados</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>

    <header>
        <h1>Institución Educativa Fermín Veras Rojas</h1>
        <p>Procesamiento del lado del Servidor (POST)</p>
    </header>

    <div class="form-container">
        <h2 style="text-align: center; margin-top: 0;">Datos Recibidos</h2>
        
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Recibimos únicamente los dos campos solicitados
            $nombre = htmlspecialchars($_POST['nombre']);
            $correo = htmlspecialchars($_POST['correo']);
            
            echo "<div class='alert alert-post'>";
            echo "👤 <strong>Nombre:</strong> " . $nombre . "<br><br>";
            echo "📧 <strong>Correo:</strong> " . $correo;
            echo "</div>";
        } else {
            echo "<p style='color: #ff6b6b;'>No se han recibido datos por el método POST.</p>";
        }
        ?>

        <div style="text-align: center;">
    <a href="/GET_Y_POST_COTO_LUIS/index.php" class="btn-regresar">⬅️ Volver al Formulario</a>
</div>
    </div>

</body>
</html>