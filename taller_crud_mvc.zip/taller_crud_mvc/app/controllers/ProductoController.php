<?php
require_once '../app/models/Producto.php';

class ProductoController {
    public function index() {
        $modelo = new Producto();
        $productos = $modelo->listar();
        require_once '../app/views/productos/index.php';
    }

    public function crear() {
        require_once '../app/views/productos/crear.php';
    }

    public function guardar() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $categoria = $_POST['categoria'];
            $precio = $_POST['precio'];
            $stock = $_POST['stock'];

            $modelo = new Producto();
            $modelo->crear($nombre, $categoria, $precio, $stock);

            header('Location: index.php?controller=producto&action=index');
        }
    }

    public function editar($id) {
        $modelo = new Producto();
        $producto = $modelo->obtenerPorId($id);
        require_once '../app/views/productos/editar.php';
    }

    public function actualizar($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $categoria = $_POST['categoria'];
            $precio = $_POST['precio'];
            $stock = $_POST['stock'];

            $modelo = new Producto();
            $modelo->actualizar($id, $nombre, $categoria, $precio, $stock);

            header('Location: index.php?controller=producto&action=index');
        }
    }

    public function eliminar($id) {
        $modelo = new Producto();
        $modelo->eliminar($id);
        header('Location: index.php?controller=producto&action=index');
    }
}
