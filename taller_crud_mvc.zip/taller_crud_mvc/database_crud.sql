CREATE DATABASE IF NOT EXISTS taller_crud_mvc;
USE taller_crud_mvc;

CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    categoria VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL
);

CREATE TABLE IF NOT EXISTS cursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_curso VARCHAR(150) NOT NULL,
    docente VARCHAR(150) NOT NULL,
    horas INT NOT NULL,
    modalidad VARCHAR(50) NOT NULL
);

-- Insertar datos de prueba
INSERT INTO productos (nombre, categoria, precio, stock) VALUES 
('Laptop HP Pavilion', 'Computación', 850.00, 15),
('Mouse Inalámbrico Logitech', 'Accesorios', 25.50, 50);

INSERT INTO cursos (nombre_curso, docente, horas, modalidad) VALUES 
('Desarrollo Web Full Stack', 'Ing. Torres', 120, 'Virtual'),
('Bases de Datos Avanzadas', 'Lic. Gomez', 80, 'Presencial');
