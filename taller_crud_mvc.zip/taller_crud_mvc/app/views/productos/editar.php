<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2 class="mb-4">Editar Producto #<?= htmlspecialchars($producto['id']) ?></h2>
    <form action="index.php?controller=producto&action=actualizar&id=<?= $producto['id'] ?>" method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Nombre del Producto</label>
            <input type="text" name="nombre" class="form-control" required value="<?= htmlspecialchars($producto['nombre']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <input type="text" name="categoria" class="form-control" required value="<?= htmlspecialchars($producto['categoria']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Precio</label>
            <input type="number" step="0.01" name="precio" class="form-control" required min="0.01" value="<?= htmlspecialchars($producto['precio']) ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Stock</label>
            <input type="number" name="stock" class="form-control" required min="0" value="<?= htmlspecialchars($producto['stock']) ?>">
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Actualizar Producto</button>
            <a href="index.php?controller=producto&action=index" class="btn btn-secondary">Volver al listado</a>
        </div>
    </form>
</body>
</html>
