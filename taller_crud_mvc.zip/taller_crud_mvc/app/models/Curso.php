<?php
require_once '../config/conexion.php';

class Curso {
    private $db;

    public function __construct() {
        $this->db = Conexion::conectar();
    }

    public function listar() {
        $stmt = $this->db->query("SELECT * FROM cursos ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function obtenerPorId($id) {
        $stmt = $this->db->prepare("SELECT * FROM cursos WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function crear($nombre_curso, $docente, $horas, $modalidad) {
        $stmt = $this->db->prepare("INSERT INTO cursos (nombre_curso, docente, horas, modalidad) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$nombre_curso, $docente, $horas, $modalidad]);
    }

    public function actualizar($id, $nombre_curso, $docente, $horas, $modalidad) {
        $stmt = $this->db->prepare("UPDATE cursos SET nombre_curso = ?, docente = ?, horas = ?, modalidad = ? WHERE id = ?");
        return $stmt->execute([$nombre_curso, $docente, $horas, $modalidad, $id]);
    }

    public function eliminar($id) {
        $stmt = $this->db->prepare("DELETE FROM cursos WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
