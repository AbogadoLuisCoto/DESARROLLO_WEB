<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CRUD de Cursos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <nav class="mb-4 bg-light p-3 rounded">
        <a href="index.php?controller=producto&action=index" class="btn btn-outline-primary">Productos (Ej 1)</a>
        <a href="index.php?controller=curso&action=index" class="btn btn-primary">Cursos (Ej 2)</a>
    </nav>
    <h2 class="mb-4">Administración de Cursos Académicos</h2>
    <a href="index.php?controller=curso&action=crear" class="btn btn-success mb-3">Registrar Nuevo Curso</a>
    
    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped mb-0">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre del Curso</th>
                    <th>Docente</th>
                    <th>Horas</th>
                    <th>Modalidad</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($cursos)): ?>
                <tr><td colspan="6" class="text-center">No hay cursos registrados.</td></tr>
                <?php else: ?>
                    <?php foreach ($cursos as $c): ?>
                    <tr>
                        <td><?= htmlspecialchars($c['id']) ?></td>
                        <td><?= htmlspecialchars($c['nombre_curso']) ?></td>
                        <td><?= htmlspecialchars($c['docente']) ?></td>
                        <td><?= htmlspecialchars($c['horas']) ?></td>
                        <td><?= htmlspecialchars($c['modalidad']) ?></td>
                        <td>
                            <a href="index.php?controller=curso&action=editar&id=<?= $c['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="index.php?controller=curso&action=eliminar&id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Está seguro de que desea eliminar este curso?');">Eliminar</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
