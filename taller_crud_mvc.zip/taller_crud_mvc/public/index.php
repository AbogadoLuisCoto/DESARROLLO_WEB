<?php
// Front Controller que redirige todas las peticiones
require_once '../config/conexion.php';

// Obtener controlador y accion de la URL, con valores por defecto
$controller = isset($_GET['controller']) ? $_GET['controller'] : 'producto';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

$controllerName = ucfirst($controller) . 'Controller';
$controllerFile = '../app/controllers/' . $controllerName . '.php';

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    $controllerObj = new $controllerName();
    
    if (method_exists($controllerObj, $action)) {
        // En caso de editar o eliminar, solemos pasar el ID por GET
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        if ($id) {
            $controllerObj->$action($id);
        } else {
            $controllerObj->$action();
        }
    } else {
        echo "Error: La acción $action no existe en $controllerName.";
    }
} else {
    echo "Error: El controlador $controllerName no existe en $controllerFile.";
}
