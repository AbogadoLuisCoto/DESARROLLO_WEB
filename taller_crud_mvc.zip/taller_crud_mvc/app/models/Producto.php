<?php
require_once '../config/conexion.php';

class Producto {
    private $db;

    public function __construct() {
        $this->db = Conexion::conectar();
    }

    public function listar() {
        $stmt = $this->db->query("SELECT * FROM productos ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function obtenerPorId($id) {
        $stmt = $this->db->prepare("SELECT * FROM productos WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function crear($nombre, $categoria, $precio, $stock) {
        $stmt = $this->db->prepare("INSERT INTO productos (nombre, categoria, precio, stock) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$nombre, $categoria, $precio, $stock]);
    }

    public function actualizar($id, $nombre, $categoria, $precio, $stock) {
        $stmt = $this->db->prepare("UPDATE productos SET nombre = ?, categoria = ?, precio = ?, stock = ? WHERE id = ?");
        return $stmt->execute([$nombre, $categoria, $precio, $stock, $id]);
    }

    public function eliminar($id) {
        $stmt = $this->db->prepare("DELETE FROM productos WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
