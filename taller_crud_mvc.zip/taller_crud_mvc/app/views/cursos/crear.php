<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar Curso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h2 class="mb-4">Registrar Nuevo Curso</h2>
    <form action="index.php?controller=curso&action=guardar" method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
            <label class="form-label">Nombre del Curso</label>
            <input type="text" name="nombre_curso" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Docente</label>
            <input type="text" name="docente" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Horas Totales</label>
            <input type="number" name="horas" class="form-control" required min="1">
        </div>
        <div class="mb-3">
            <label class="form-label">Modalidad</label>
            <select name="modalidad" class="form-select" required>
                <option value="">Seleccione una opción...</option>
                <option value="Presencial">Presencial</option>
                <option value="Virtual">Virtual</option>
                <option value="Híbrida">Híbrida</option>
            </select>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Guardar Curso</button>
            <a href="index.php?controller=curso&action=index" class="btn btn-secondary">Volver al listado</a>
        </div>
    </form>
</body>
</html>
