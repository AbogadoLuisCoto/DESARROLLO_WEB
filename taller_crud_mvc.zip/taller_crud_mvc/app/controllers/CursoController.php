<?php
require_once '../app/models/Curso.php';

class CursoController {
    public function index() {
        $modelo = new Curso();
        $cursos = $modelo->listar();
        require_once '../app/views/cursos/index.php';
    }

    public function crear() {
        require_once '../app/views/cursos/crear.php';
    }

    public function guardar() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre_curso = $_POST['nombre_curso'];
            $docente = $_POST['docente'];
            $horas = $_POST['horas'];
            $modalidad = $_POST['modalidad'];

            $modelo = new Curso();
            $modelo->crear($nombre_curso, $docente, $horas, $modalidad);

            header('Location: index.php?controller=curso&action=index');
        }
    }

    public function editar($id) {
        $modelo = new Curso();
        $curso = $modelo->obtenerPorId($id);
        require_once '../app/views/cursos/editar.php';
    }

    public function actualizar($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre_curso = $_POST['nombre_curso'];
            $docente = $_POST['docente'];
            $horas = $_POST['horas'];
            $modalidad = $_POST['modalidad'];

            $modelo = new Curso();
            $modelo->actualizar($id, $nombre_curso, $docente, $horas, $modalidad);

            header('Location: index.php?controller=curso&action=index');
        }
    }

    public function eliminar($id) {
        $modelo = new Curso();
        $modelo->eliminar($id);
        header('Location: index.php?controller=curso&action=index');
    }
}
